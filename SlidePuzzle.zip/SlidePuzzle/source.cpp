#include <bangtal.h>

SceneID scene1, scene2;
ObjectID problem1, problem2, problem3, problem4, problem5, problem6, problem7, problem8;
ObjectID start, end, hint, restart;
int x1, x2, x3, x4, x5, x6, x7, x8;
int y1, y2, y3, y4, y5, y6, y7, y8;
int x0 = 640;
int y0 = 980;

void endGame(bool starttype) 
{
	locateObject(problem1, scene2, 640, 600);
	locateObject(problem2, scene2, 830, 790);
	locateObject(problem3, scene2, 1020, 600);
	locateObject(problem4, scene2, 830, 980);
	locateObject(problem5, scene2, 830, 600);
	locateObject(problem6, scene2, 1020, 790);
	locateObject(problem7, scene2, 1020, 980);
	locateObject(problem8, scene2, 640, 790);
	if (starttype) 
	{
		endGame();
	}
	else 
	{
		enterScene(scene1);
	}
}

void restartcheck() 
{
	if (x1 == 640 && x4 == 640 && x7 == 640 && x2 == 830 && x5 == 830 && x8 == 830 && x3 == 1020 && x6 == 1020)
	{
		if (y1 == 600 && y2 == 600 && y3 == 600 && y4 == 790 && y5 == 790 && y6 == 790 && y7 == 980 && y8 == 980)
		{
			showMessage("����Ŭ����");
			endGame(true);
		}
	}
}

void save(ObjectID object, int x, int y) 
{
	if (object == problem1) 
	{
		x1 = x;
		y1 = y;
	}
	else if (object == problem2)
	{
		x2 = x;
		y2 = y;
	}
	else if (object == problem3)
	{
		x3 = x;
		y3 = y;
	}
	else if (object == problem4)
	{
		x4 = x;
		y4 = y;
	}
	else if (object == problem5)
	{
		x5 = x;
		y5 = y;
	}
	else if (object == problem6)
	{
		x6 = x;
		y6 = y;
	}
	else if (object == problem7)
	{
		x7 = x;
		y7 = y;
	}
	else if (object == problem8)
	{
		x8 = x;
		y8 = y;
	}
	restartcheck();
}

void mousedragcallback(ObjectID object, int x, int y, MouseAction action)
{
	if (action == MouseAction::MOUSE_DRAG_DOWN)
	{
		y = y - 190;
		if (x == x0 && y == y0)
		{
			locateObject(object, scene2, x, y);
			y0 = y0 + 190;

			save(object, x, y);
		}
	}
	else if (action == MouseAction::MOUSE_DRAG_UP)
	{
		y = y + 190;
		if (x == x0 && y == y0)
		{
			locateObject(object, scene2, x, y);
			y0 = y0 - 190;

			save(object, x, y);
		}
	}
	else if (action == MouseAction::MOUSE_DRAG_LEFT)
	{
		x = x - 190;
		if (x == x0 && y == y0)
		{
			locateObject(object, scene2, x, y);
			x0 = x0 + 190;

			save(object, x, y);
		}
	}
	else if (action == MouseAction::MOUSE_DRAG_RIGHT)
	{
		x = x + 190;
		if (x == x0 && y == y0)
		{
			locateObject(object, scene2, x, y);
			x0 = x0 - 190;

			save(object, x, y);
		}
	}
}

void mousecallback(ObjectID object, int x, int y, MouseAction action)
{
	if (object == problem1) 
	{
		mousedragcallback(object, x, y,action);
	}
	else if (object == problem2) 
	{
		mousedragcallback(object, x, y, action);
	}
	else if (object == problem3)
	{
		mousedragcallback(object, x, y, action);
	}
	else if (object == problem4)
	{
		mousedragcallback(object, x, y, action);
	}
	else if (object == problem5)
	{
		mousedragcallback(object, x, y, action);
	}
	else if (object == problem6)
	{
		mousedragcallback(object, x, y, action);
	}
	else if (object == problem7)
	{
		mousedragcallback(object, x, y, action);
	}
	else if (object == problem8)
	{
		mousedragcallback(object, x, y, action);
	}
	else if (object == start) 
	{
		enterScene(scene2);
	}
	else if (object == end) 
	{
		endGame();
	}
	else if (object == restart) 
	{
		endGame(false);
	}
}

ObjectID createObject(const char* image, SceneID scene, int x, int y, bool shown, float scale)
{
	ObjectID object = createObject(image);

	scaleObject(object, scale);

	locateObject(object, scene, x, y);


	if (shown)
	{
		showObject(object);
	}

	return object;
}

int main() 
{
	setMouseCallback(mousecallback);
	scene1 = createScene("�����̵� ����", "starting.png");
	scene2 = createScene("����", "Background.png");

	start = createObject("start.png", scene1, 930, 960, true,1.0f);
	end = createObject("end.png", scene1, 930, 910, true, 1.0f);
	restart = createObject("restart.png", scene2, 440, 650, true, 1.0f );

	problem1 = createObject("problem-1.png", scene2, 640, 600, true, 0.3f);
	problem2 = createObject("problem-2.png", scene2, 830, 790, true, 0.3f);
	problem3 = createObject("problem-3.png", scene2, 1020, 600, true, 0.3f);
	problem4 = createObject("problem-4.png", scene2, 830, 980, true, 0.3f);
	problem5 = createObject("problem-5.png", scene2, 830, 600, true, 0.3f);
	problem6 = createObject("problem-6.png", scene2, 1020, 790, true, 0.3f);
	problem7 = createObject("problem-7.png", scene2, 1020, 980, true, 0.3f);
	problem8 = createObject("problem-8.png", scene2, 640, 790, true, 0.3f);

	startGame(scene1);
}